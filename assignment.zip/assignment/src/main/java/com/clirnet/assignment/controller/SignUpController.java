package com.clirnet.assignment.controller;

import com.clirnet.assignment.dto.CreateUserDTO;
import com.clirnet.assignment.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class SignUpController {
    private final UserService userService;

    public SignUpController(UserService userService) {
        this.userService = userService;
    }

    @RequestMapping(value="/create-user", method= RequestMethod.POST)
    public ResponseEntity<?> createUser(@RequestBody CreateUserDTO request) {
        try {
            CreateUserDTO response = userService.createUser(request);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (Exception e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }

    }

}
