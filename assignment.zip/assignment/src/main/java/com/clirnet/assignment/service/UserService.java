package com.clirnet.assignment.service;

import com.clirnet.assignment.dto.CreateUserDTO;

public interface UserService {
    CreateUserDTO createUser(CreateUserDTO request);
}
