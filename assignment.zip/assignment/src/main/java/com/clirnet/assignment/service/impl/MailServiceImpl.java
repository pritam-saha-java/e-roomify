package com.clirnet.assignment.service.impl;

import com.clirnet.assignment.dto.CreateUserDTO;
import com.clirnet.assignment.service.MailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class MailServiceImpl implements MailService {

    private static final Logger log = LoggerFactory.getLogger(MailServiceImpl.class);
    private final JavaMailSender javaMailSender;

    public MailServiceImpl(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    @Value("${spring.mail.username}")
    private String sender;

    @Override
    @Async
    public void sendMail(CreateUserDTO request) {
        try {
            SimpleMailMessage mailMessage = new SimpleMailMessage();

            mailMessage.setFrom(sender);
            mailMessage.setTo(request.getEmail());
            mailMessage.setText("New User Created With Name: " + request.getFirstName() + " " + request.getLastName());
            mailMessage.setSubject("New User Created");

            javaMailSender.send(mailMessage);
            log.info("Mail Send Successfully");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
