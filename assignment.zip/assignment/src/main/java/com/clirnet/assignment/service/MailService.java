package com.clirnet.assignment.service;

import com.clirnet.assignment.dto.CreateUserDTO;

public interface MailService {

    void sendMail(CreateUserDTO request);
}
