package com.clirnet.assignment.service.impl;

import com.clirnet.assignment.dto.CreateUserDTO;
import com.clirnet.assignment.entity.UserEntity;
import com.clirnet.assignment.repository.UserRepository;
import com.clirnet.assignment.service.MailService;
import com.clirnet.assignment.service.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    public final MailService mailService;

    public UserServiceImpl(UserRepository userRepository, MailService mailService) {
        this.userRepository = userRepository;
        this.mailService = mailService;
    }

    @Override
    public CreateUserDTO createUser(CreateUserDTO request){
        Optional<UserEntity> user = userRepository.findByEmail(request.getEmail());
        if (user.isPresent()) {
            throw new RuntimeException("User Already Exist");
        }

        UserEntity entity = new UserEntity();
        BeanUtils.copyProperties(request, entity);
        userRepository.save(entity);

        mailService.sendMail(request);
        return request;
    }
}
